package com.tallerwebi.dominio.excepcion;

public class NombreDeUsuarioRepetido extends Exception{
}
