package com.tallerwebi.dominio.excepcion;

public class UsuarioExistente extends Exception {

}

