package com.tallerwebi.dominio.excepcion;

public class ContrasenasDistintas extends Exception{
}
